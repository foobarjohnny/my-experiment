#include <iostream>
#include <string>
#include <memory.h>
#include <math.h>

using namespace std;

int main()
{
    int n;
    while (cin >> n && n > 0)
    {
        double first = -1.0;
        for (int i = 0; i < n; ++i)
        {
            int speed, start;
            cin >> speed >> start;

            if (start >= 0)
            {
                double current = 4.5 / speed * 3600 + start;
                if (first < 0 || first > current)
                    first = current;
            }
        }

        cout << ceil(first) << endl;
    }

    return 0;
}
