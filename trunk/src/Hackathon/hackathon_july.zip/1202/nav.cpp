#include <iostream>
#include <string>
#include <memory.h>
#include <limits.h>

using namespace std;

int main()
{
    const int Max = 100;
    int dist[Max][Max];     // Distance.
    int sdist[Max][Max];    // Shortest distance.
    int path[Max];          // Path.

    int n, m;
    int no = 0;
    while (cin >> n && n > 0)
    {
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                cin >> dist[i][j];
                if (dist[i][j] == 0)
                    dist[i][j] = INT_MAX / 2;
            }
            dist[i][i] = 0;
        }
        memcpy(sdist, dist, sizeof(dist));

        cin >> m;
        for (int i = 0; i < m; ++i)
            cin >> path[i];

        // Floyd-Warshall algorithm.  Calculate shortest distance between all pairs.
        for (int k = 0; k < n; ++k)
            for (int i = 0; i < n; ++i)
                for (int j = 0; j < n; ++j)
                    sdist[i][j] = min(sdist[i][j], sdist[i][k] + sdist[k][j]);

        // Greedy algorithm.  Add a road as late as possible.
        // Proof by contradiction.  Assume there exist another new config with fewer roads.
        // Since above roads are added as late as possible, there will be one road in new config which appears earlier along the path, and its next road cannot be later (else there must be a shorter path between).
        // But then we can move that road to the position of old config without affecting the shortest distance or config of other roads.  Continue this process and finally get contradiction.
        int lastIdx = 0;
        int road = 0;
        for (int i = 1; i < m; ++i)
        {
            if (sdist[path[lastIdx]][path[i-1]] + dist[path[i-1]][path[i]] > sdist[path[lastIdx]][path[i]])
            {
                ++road;
                lastIdx = i;
            }
        }

        cout << "Case " << (++no) << ": " << road << endl;
    }

    return 0;
}
