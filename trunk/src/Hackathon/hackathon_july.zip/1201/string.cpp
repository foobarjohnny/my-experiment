#include <iostream>
#include <string>

using namespace std;

bool checkString(const string &line, int size)
{
    if (line.size() % size != 0)
        return false;

    int turns = line.size() / size;
    for (int i = 0; i < turns; ++i)
        for (int j = 0; j < size; ++j)
            if (line[i * size + j] != line[j])
                return false;

    return true;
}

int main()
{
    string line;
    while (getline(cin, line))
    {
        if (line == ".")
            break;

        int num = 1;
        for (int i = 1; i <= line.size() / 2; ++i)
        {
            if (checkString(line, i))
            {
                num = line.size() / i;
                break;
            }
        }

        cout << num << endl;
    }

    return 0;
}
